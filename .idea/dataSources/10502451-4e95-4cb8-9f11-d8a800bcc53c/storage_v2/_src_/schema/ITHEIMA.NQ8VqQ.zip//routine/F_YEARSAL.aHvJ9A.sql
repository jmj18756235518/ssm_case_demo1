CREATE function f_yearsal(eno emp.empno%type)
return number
is
s number;
begin
  select sal*12+nvl(comm,0) into s from emp where empno = eno;
  return s;

end;
/

