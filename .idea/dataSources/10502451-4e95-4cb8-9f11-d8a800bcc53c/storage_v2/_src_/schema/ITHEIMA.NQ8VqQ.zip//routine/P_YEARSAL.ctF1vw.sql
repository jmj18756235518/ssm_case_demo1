CREATE procedure p_yearsal(eno emp.empno%type,yearsal out number)
is
 s number(10);
 c emp.comm%type;
begin
  select sal*12,nvl(comm,0) into s,c from emp where empno = eno;
  yearsal := s+c;
end;
/

